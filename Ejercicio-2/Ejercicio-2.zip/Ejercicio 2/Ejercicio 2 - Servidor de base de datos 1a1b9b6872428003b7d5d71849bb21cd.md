# Ejercicio 2 - Servidor de base de datos

> Realizado: Dani Gayol y Adrián Fernández
> 

## Resolución

### 1. Abre Docker Desktop. Busca mariadb en la sección de imágenes. Selecciona la imagen oficial. Descárgala si no la tienes.

![image-20250220092408010.png](image-20250220092408010.png)

### 2. Despliega un contenedor utilizando esa imagen.

![image-20250220093621226.png](image-20250220093621226.png)

![image-20250220094357704.png](image-20250220094357704.png)

### 3. Arranca el contenedor

![image-20250220094750704.png](image-20250220094750704.png)

### 4. Accede a la base de datos usando una herramienta gráfica, como, por ejemplo dbeaver . Conéctate con el usuario daw . Crea una base de datos y alguna tabla.

Primero instalamos y abrimos DBeaver

![image-20250220095518188.png](image-20250220095518188.png)

![image-20250220095735078.png](image-20250220095735078.png)

![image-20250220095829015.png](image-20250220095829015.png)

![image-20250220095953096.png](image-20250220095953096.png)

Probamos la conexión y finalizamos

![image-20250220100102377.png](image-20250220100102377.png)

Ahora vamos a crear la base de datos

![image-20250220100319546.png](image-20250220100319546.png)

Creamos otra conexión root para dar permisos a daw

![image-20250220101518715.png](image-20250220101518715.png)

Y creamos la base de datos y la tabla

![image-20250220100700821.png](image-20250220100700821.png)

![image-20250221090026897.png](image-20250221090026897.png)

### 5. Borra el contenedor

Primero lo pausamos 

![image.png](image.png)

A continuación lo eliminamos

![image.png](image%201.png)

### 6. Ver en Docker Desktop que el volumen que contiene los datos no se ha borrado

![image.png](image%202.png)

### 7. Crear otro contenedor con un servidor de base de datos que use el mismo volumen. Llamar al contenedor bbdd-2 . Comprobar que la base de datos y la tabla creada anteriormente siguen ahí.

![image.png](image%203.png)

Como podemos ver sigue estando la tabla en dbeaver

![image.png](image%204.png)

### 8. Intenta borrar la imagen de mariadb ¿Qué sucede?

![image.png](image%205.png)

![image.png](image%206.png)

### 9. Borra todo, volumen, imagen y contenedor.

![image.png](image%207.png)

![image.png](image%208.png)

![image.png](image%209.png)