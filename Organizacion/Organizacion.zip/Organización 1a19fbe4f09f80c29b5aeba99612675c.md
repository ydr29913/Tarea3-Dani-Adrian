# Organización

> Realizado: Dani y Adrián
> 

## Asignación de Tareas

- Ejercicio 1: Dani
- Ejercicio 2: Adrián
- Ejercicio 3: Adrián
- Ejercicio 4: Dani
- Ejercicio 5: Dani

## Plazo Estimado

|  | **Plazo Estimado** |
| --- | --- |
| **Ejercicio 1** | 14/02/2025 |
| **Ejercicio 2** | 14/02/2025 |
| **Ejercicio 3** | 17/02/2025 |
| **Ejercicio 4** | 18/02/2025 |
| **Ejercicio 5** | 19/02/2025 |

## Plazo Final

|  | **Plazo Final** |
| --- | --- |
| **Ejercicio 1** | 14/02/2025 |
| **Ejercicio 2** | 21/02/2025 |
| **Ejercicio 3** | 19/02/2025 |
| **Ejercicio 4** | 18/02/2025 |
| **Ejercicio 5** | 21/02/2025 |