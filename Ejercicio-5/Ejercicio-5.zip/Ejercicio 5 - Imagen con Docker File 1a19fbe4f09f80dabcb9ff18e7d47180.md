# Ejercicio 5 - Imagen con Docker File

> Realizado: Dani Gayol Rodriguez
> 

## Creación del Contenedor

```bash
$ docker run -d --name web -p 8000:80 php:7.4-apache
```

![image.png](image.png)

## Ficheros

html:

![image.png](image%201.png)

css:

![image.png](image%202.png)

vista:

```bash
$ docker cp /var/www/html/index-docker.html web:/var/www/html
$ docker cp /var/www/html/styles-docker.css web:/var/www/html
```

![image.png](image%203.png)

![image.png](image%204.png)

script:

![image.png](image%205.png)

![image.png](image%206.png)

## Bloque código Dockerfile

Dockerfile:

![image.png](image%207.png)

```bash
$ docker exec web ls -l /var/www/html
```

![image.png](image%208.png)

## Imagen Docker

```bash
$ docker build -t ydr29913/miapp:latest .
```

![image.png](image%209.png)

## Docker Hub

```bash
$ docker login -u <nombre-usuario>
```

![image.png](image%2010.png)

## Descarga de la Imagen

```bash
$ docker pull ydr29913/miapp:latest
```

![image.png](image%2011.png)

## Acceso al Sitio Web

```bash
$ docker run -d -p 8000:80 ydr29913/miapp
```

![image.png](image%2012.png)

![image.png](image%2013.png)

## Docker Hub imagen

![image.png](image%2014.png)