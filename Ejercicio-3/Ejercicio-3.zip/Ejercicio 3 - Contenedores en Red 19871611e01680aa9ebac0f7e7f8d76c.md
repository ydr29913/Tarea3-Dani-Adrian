# Ejercicio 3 - Contenedores en Red

> Realizado:
> 

## Introducción

Para la resolución de este ejercicio en docker primero debemos abrir el bash en nuestro repositorio local y desde ahí comenzaremos a trabajar.

### 1. Crea una red bridge redbd

```bash
docker network create --driver bridge redbd
docker network ls
docker network inspect redbd
```

![image.png](image.png)

### 2. Crea un contenedor con una imagen de mariaDB que estará en la red redbd.

Este contenedor se ejecutará en segundo plano, y será accesible a través del puerto 3306. (Es
necesario definir la contraseña del usuario root y un volumen de datos persistente)

```bash
docker run -d \
  --name mariadb_container \
  --network redbd \
  -e MYSQL_ROOT_PASSWORD=tu_contraseña \
  -p 3306:3306 \
  -v mariadb_data:/var/lib/mysql \
  mariadb:latest

docker ps
docker volume ls
```

![image.png](image%201.png)

![image.png](image%202.png)

### 3. Crear un contenedor con Adminer o con phpMyAdmin que se pueda conectar al contenedor de la BD

```bash
docker run -d \
  --name phpmyadmin \
  --network redbd \
  -e PMA_HOST=mariadb_container \
  -p 8081:80 \
  phpmyadmin
```

Luego, accede a: http://localhost:8081

![image.png](image%203.png)

![image.png](image%204.png)